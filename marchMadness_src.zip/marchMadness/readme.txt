/****************************************************************************************
 *                                                                                      *
 *                            @author Jin and Robert                                    *
 *                                                                                      *
 ****************************************************************************************/
 
 dist folder contains marchMadness.zip
 unzip the file
 
 to run marchMadness.zip
 1. open cmd
 2. cd to directory had marchMadness.jar
 3. to run "java -jar marchMadness.jar"